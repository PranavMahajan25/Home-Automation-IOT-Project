package com.example.pranav.homeautomation;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ToggleButton;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;




public class MainActivity extends AppCompatActivity {

    TextView tv1;
    Button b1;
    Button b2;
    String tempstr;
    int temp;\
    int l1 =0;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        tv1=(TextView)findViewById(R.id.tv1);
        b1=(Button)findViewById(R.id.bt1);
        b2=(Button)findViewById(R.id.bt2);
        ToggleButton tb1 = (ToggleButton) findViewById(R.id.tb1);


        databaseReference= FirebaseDatabase.getInstance().getReference();//DataRef is key, dataSnapshot is value

        temp=22;
        tempstr=String.valueOf(temp);
        tv1.setText(tempstr+"°C");


        b1.setOnClickListener(new View.OnClickListener()

            {
                @Override
                public void onClick (View view){

                temp++;
                tempstr = String.valueOf(temp);
                tv1.setText(tempstr + "°C");

                databaseReference.child("AppValue").setValue(temp);
                //    databaseReference.child("AppValue").child(temp).removeValue();

                //int temp = tempstr.getValue(Integer.class);
            }
            });

        b2.setOnClickListener(new View.OnClickListener()

            {
                @Override
                public void onClick (View view){

                temp--;
                tempstr = String.valueOf(temp);
                tv1.setText(tempstr + "°C");

                databaseReference.child("AppValue").setValue(temp);
            }
            });

        tb1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // The toggle is enabled
                    l1=1;
                    databaseReference.child("Light1").setValue(l1);
                } else {
                    // The toggle is disabled
                    l1=0;
                    databaseReference.child("Light1").setValue(l1);
                }
            }
        });


    }
}
