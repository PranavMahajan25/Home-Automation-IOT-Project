package com.example.pranav.homeautomation;

import static org.junit.Assert.*;

/**
 * Created by pranav on 3/6/18.
 */
public class MainActivityTest {

}